import React, { Component } from "react"
import "./style.css"

function mainBG() {
    return (
        <>
            <div id='stars'></div>
            <div id='stars2'></div>
            <div id='stars3'></div>
            <div id='title' />
                <span>
                    PURE CSS
            </span>
                <br />
                    <span>
                        PARALLAX PIXEL STARS
            </span>
                    <div />
        </>
    )
}

export default mainBG;