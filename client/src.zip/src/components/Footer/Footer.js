import React from "react";
import "./Footer.css";

function Footer() {
    return (

        <section className="container">
            <div id='layout_footer'>
            </div>
            <div id='footer'>
                ASTERIA Copyright 2020
            </div>
        </section>

    )
}
export default Footer;